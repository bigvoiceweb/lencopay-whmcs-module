<?php

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

/* ===============================
   LOAD GATEWAY CONFIG
=============================== */
$gatewayParams = getGatewayVariables('lencopay');
if (!$gatewayParams['type']) {
    http_response_code(403);
    exit('Gateway inactive');
}

/* ===============================
   READ RAW WEBHOOK PAYLOAD
=============================== */
$rawPayload = file_get_contents('php://input');
$data = json_decode($rawPayload, true);

if (empty($data['event']) || empty($data['data'])) {
    http_response_code(200);
    exit('No webhook data');
}

$event = $data['event'];
$payload = $data['data'];

/* ===============================
   ACCEPT ONLY SUCCESSFUL PAYMENTS
=============================== */
if (($payload['status'] ?? '') !== 'successful') {
    logTransaction('Lenco Pay', $payload, 'Ignored Non-Success');
    http_response_code(200);
    exit('Ignored');
}

/* ===============================
   GET REFERENCE
=============================== */
$reference = $payload['reference'] ?? '';
if (!$reference) {
    logTransaction('Lenco Pay', $payload, 'Missing Reference');
    http_response_code(400);
    exit('No reference');
}

/* ===============================
   EXTRACT INVOICE ID
   Example: WHMCSZMW_14_1767898940
=============================== */
if (!preg_match('/WHMCSZMW_(\d+)_/', $reference, $matches)) {
    logTransaction('Lenco Pay', $reference, 'Invalid Reference Format');
    http_response_code(400);
    exit('Bad reference');
}

$invoiceId = (int) $matches[1];
$invoiceId = checkCbInvoiceID($invoiceId, 'lencopay');

/* ===============================
   PREVENT DUPLICATE PAYMENTS
=============================== */
checkCbTransID($reference);

/* ===============================
   NORMALIZE AMOUNT
=============================== */
$amount = (float) $payload['amount'];
if ($amount <= 0) {
    logTransaction('Lenco Pay', $payload, 'Invalid Amount');
    http_response_code(400);
    exit('Invalid amount');
}

/* ===============================
   APPLY PAYMENT TO WHMCS
=============================== */
addInvoicePayment(
    $invoiceId,
    $reference,
    $amount,
    0,
    'lencopay'
);

/* ===============================
   LOG SUCCESS
=============================== */
logTransaction(
    'Lenco Pay',
    [
        'event'     => $event,
        'invoiceId' => $invoiceId,
        'reference' => $reference,
        'amount'    => $amount,
        'currency'  => $payload['currency'] ?? 'ZMW'
    ],
    'Payment Applied Successfully'
);

http_response_code(200);
echo 'OK';
