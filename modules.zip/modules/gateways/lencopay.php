<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/* =================================
   METADATA
================================= */
function lencopay_MetaData()
{
    return [
        'DisplayName' => 'Lenco Pay (Zambia)',
        'APIVersion'  => '1.1',
        'Description' => 'Accept card and mobile money payments in Zambia using Lenco Pay.',
        'Category'    => 'Payments',
        'Author'      => 'BIG VOICE TECHNOLOGIES',
        'CompanyName' => 'ICOF Innovation Inc',
        'Support'     => 'https://lenco-api.readme.io',
    ];
}

/* =================================
   CONFIG
================================= */
function lencopay_config()
{
    return [
        'FriendlyName' => [
            'Type'  => 'System',
            'Value' => 'Lenco Pay (Zambia)',
        ],
        'publicKey' => [
            'FriendlyName' => 'Public Key',
            'Type' => 'text',
            'Size' => '100',
        ],
        'secretKey' => [
            'FriendlyName' => 'Secret Key',
            'Type' => 'password',
            'Size' => '100',
        ],
    ];
}

/* =================================
   PAYMENT BUTTON + UI SUCCESS
================================= */
function lencopay_link($params)
{
    $publicKey = $params['publicKey'];
    $invoiceId = (int)$params['invoiceid'];
    $amount    = number_format($params['amount'], 2, '.', '');
    $email     = $params['clientdetails']['email'];
    $firstName = $params['clientdetails']['firstname'];
    $lastName  = $params['clientdetails']['lastname'];
    $phone     = $params['clientdetails']['phonenumber'];
    $systemUrl = rtrim($params['systemurl'], '/');

    $reference = "WHMCSZMW_{$invoiceId}_" . time();

    return <<<HTML
<script src="https://pay.lenco.co/js/v1/inline.js"></script>

<button type="button" class="btn btn-success btn-lg" onclick="payWithLenco()">
    Pay with Lenco (ZMW)
</button>

<style>
#lenco-success {
    position: fixed;
    inset: 0;
    background: radial-gradient(circle at center, #0f172a, #020617);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    font-family: system-ui;
}
.lenco-box {
    text-align: center;
    padding: 45px;
    border-radius: 20px;
    background: rgba(15, 23, 42, 0.95);
    box-shadow: 0 0 25px #22c55e, 0 0 70px rgba(34,197,94,.7);
    animation: glow 2s infinite;
}
@keyframes glow {
    0% { box-shadow: 0 0 20px #22c55e; }
    50% { box-shadow: 0 0 70px #22c55e; }
    100% { box-shadow: 0 0 20px #22c55e; }
}
.lenco-check {
    font-size: 80px;
    color: #22c55e;
}
.lenco-text {
    font-size: 26px;
    color: #e5e7eb;
    margin-top: 10px;
}
.lenco-sub {
    color: #94a3b8;
    margin-top: 5px;
}
.lenco-actions {
    margin-top: 25px;
}
.lenco-actions a {
    display: inline-block;
    margin: 5px;
    padding: 12px 22px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
}
.view-receipt {
    background: #22c55e;
    color: #022c22;
}
.view-invoices {
    background: #020617;
    color: #22c55e;
    border: 1px solid #22c55e;
}
.lenco-count {
    margin-top: 15px;
    color: #22c55e;
}
</style>

<div id="lenco-success">
    <div class="lenco-box">
        <div class="lenco-check">✔</div>
        <div class="lenco-text">Payment Successful</div>
        <div class="lenco-sub">Thank you for your payment</div>

        <div class="lenco-actions">
            <a class="view-receipt"
               href="{$systemUrl}/viewinvoice.php?id={$invoiceId}"
               target="_blank">
               View Receipt
            </a>

            <a class="view-invoices"
               href="{$systemUrl}/clientarea.php?action=invoices">
               Go to Invoices
            </a>
        </div>

        <div class="lenco-count">
            Redirecting in <span id="lenco-count">4</span>…
        </div>
    </div>
</div>

<script>
function payWithLenco() {
    if (typeof LencoPay === 'undefined') {
        alert('Lenco checkout failed to load.');
        return;
    }

    LencoPay.getPaid({
        key: "{$publicKey}",
        reference: "{$reference}",
        email: "{$email}",
        amount: {$amount},
        currency: "ZMW",
        channels: ["card", "mobile-money"],
        customer: {
            firstName: "{$firstName}",
            lastName: "{$lastName}",
            phone: "{$phone}"
        },
        onSuccess: function () {
            showLencoSuccess();
        }
    });
}

function showLencoSuccess() {
    const box = document.getElementById('lenco-success');
    const count = document.getElementById('lenco-count');

    box.style.display = 'flex';

    let seconds = 4;
    const timer = setInterval(() => {
        seconds--;
        count.innerText = seconds;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href =
              "{$systemUrl}/clientarea.php?action=invoices";
        }
    }, 1000);
}
</script>
HTML;
}
